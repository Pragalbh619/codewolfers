import codewolfers_logo from "./media/codewolfers_logo.png"
import bg from "./media/bg.png"
import WhoWeAre from "./media/WhoWeAre.png"
import AD1 from "./media/AD1.avif"
import WD1 from "./media/WD1.avif"
import OS1 from "./media/OS1.avif" 
import WF  from "./media/WF.png"
// import about from "./media/about.webp"

export const cdImg = {
    logo: codewolfers_logo,
    background: bg,
    WhoWeAre: WhoWeAre,
    AD1: AD1,
    WD1: WD1,
    OS1: OS1,
    WF: WF
    // about: about
}